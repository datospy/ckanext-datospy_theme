# Proceso de instalación de la plataforma ckan destinada al catálogo de datos abiertos y el portal para la Sociedad Civil del Paraguay.

El manual basado en la [documentación oficial ](http://docs.ckan.org/en/ckan-2.2/install-from-source.html)de la plataforma y el manual de instalacion de [datosparaguay.org.py](http://datosparaguay.org/xwiki/bin/view/CKAN_Guide/)

  

Caracteristicas

  

- Versión ckan(catalogo): 2.2.1 
- Versión drupal(portal): 
- Servidor: Ubuntu 14.04 

Hardware: 

- 1x Intel® Xeon® E3 1220 v2 
- 16 GB DDR3 
- Conexión de 150Mbps 
- 1 TB 
  

Instalacion

  

1.Actualizar la base de datos de paquetes de Ubuntu 
  

`sudo apt-get update`

  

2.Instalar los paquetes requeridos  
  

`sudo apt-get install python-dev postgresql libpq-dev python-pip python-virtualenv git-core openjdk-6-jdk solr-tomcat`

  

3.Modificar el puerto donde escucha el servidor tomcat. La instalación oficial utiliza jetty como servidor, pero debido a problemas de versiones con ubuntu 14.04 se optó por un servidor tomcat. En la línea donde dice 8080 cambiar por 8983 
  

`vim /etc/tomcat/server.xml`

  

4.Crear el directorio de acceso y un link simbólico al directorio de instalación 
  

`mkdir -p ~/ckan/libsudo`     
`ln -s ~/ckan/lib /usr/lib/ckan`    
`mkdir -p ~/ckan/etcsudo`    
`ln -s ~/ckan/etc /etc/ckan`     

  

5.Crear el entorno virtual de Python y activarlo. Tener en cuenta que cada vez que se trabaje con la plataforma se debe tener activado el entorno virtual. 
  

`sudo mkdir -p /usr/lib/ckan/defaultsudo`  
`chown whoami /usr/lib/ckan/defaultvirtualenv --no-site-packages`  
`/usr/lib/ckan/default.`   
`/usr/lib/ckan/default/bin/activate`   

6.Instalar Ckan 2.2.1 y todas sus dependencias. 

`pip install -e 'git+https://github.com/ckan/ckan.git@ckan-2.2.1#egg=ckan'`  
`pip install -r /usr/lib/ckan/default/src/ckan/requirements.txt`  

Verificar el correcto funcionamiento:

`deactivate.`  
`/usr/lib/ckan/default/bin/activate`  

7.Crear el usuario y la base de datos postgres. Es importante anotar la contraseña seteada al usuario. 

`sudo -u postgres createuser -S -D -R -P ckan_default`  
`sudo -u postgres createdb -O ckan_default ckan_default -E utf-8`  

8.Crear el archivo de configuración. Es importante recalcar que normalmente se tienen dos archivos de configuración, development.ini y production.ini, esto para el entorno de desarrollo y de producción respectivamente. El tutorial utilizará el archivo development.ini 

`sudo mkdir -p /etc/ckan/defaultsudo chown -R whoami /etc/ckan/`  
`cd /usr/lib/ckan/default/src/ckan`  
`paster make-config ckan /etc/ckan/default/development.ini`  

9.Editar el archivo de configuración con los datos de autenticación para la base de datos. 

`vim /etc/ckan/default/development.ini`  
`sqlalchemy.url = postgresql://ckan_default:pass@localhost/ckan_default`  

10.Cada Ckan debe tener un site_id unico. Para esto editamos la siguiente linea del archivo development.ini 

`ckan.site_id=default`  

  

11.Crear el archivo de configuración para el Solr y reiniciar el servidor TomCat 

`sudo mv /etc/solr/conf/schema.xml /etc/solr/conf/schema.xml.bak`  
`sudo ln -s /usr/lib/ckan/default/src/ckan/ckan/config/solr/schema.xml /etc/solr/conf/schema.xml`  
`sudo service tomcat6 restart`   

 Verificar el correcto funcionamiento:

curl  [http://localhost:8983/solr/](http://localhost:8983/solr/)  

12.Modificar la configuración del ckan para que utilice el servidor sorl 

`vim /etc/ckan/default/development.ini`  
`solr_url=http://127.0.0.1:8983/solr`  

13.Crear las tablas en la base de datos 

`cd /usr/lib/ckan/default/src/ckan`  
`paster db init -c /etc/ckan/default/development.ini`  

Debería aparecer el siguiente mensaje:

`Initialising DB: SUCCESS.`  

14.Crear el link a who.ini 
  

`ln -s /usr/lib/ckan/default/src/ckan/who.ini /etc/ckan/default/who.ini`

15.Verificar el funcionamiento de la plataforma, para esto se debe levantar un servidor de prueba con el siguiente comando 
  

`cd /usr/lib/ckan/default/src/ckanpaster serve /etc/ckan/default/development.ini`  

Abrimos en un navegador el link  [http://127.0.0.1:5000/](http://127.0.0.1:5000/) y deberiamos ver la página principal del CKAN