import ckan.plugins as plugins


class ExampleIAuthFunctionsPlugin(plugins.SingletonPlugin):
    pass
