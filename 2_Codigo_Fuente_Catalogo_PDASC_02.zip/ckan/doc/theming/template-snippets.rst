===========================
Template snippets reference
===========================

.. todo::

   Autodoc all the default template snippets here.
   This probably means writing a Sphinx plugin.
