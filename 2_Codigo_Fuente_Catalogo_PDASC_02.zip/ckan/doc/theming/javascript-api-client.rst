===============================
JavaScript API client reference
===============================

.. todo::

   Autodoc the |javascript| client.
   This will probably require writing a custom Sphinx plugin.
