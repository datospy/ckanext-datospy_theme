=============================
CKAN jQuery plugins reference
=============================

CKAN adds a number of custom plugins that can be accessed by JavaScript modules
via :js:data:`this.sandbox.jQuery`.

.. todo: Autodoc them.
